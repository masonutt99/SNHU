package com.example.weighttrackingappweek5;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


//This is the base of the app
//The app starts here and everything stems from this page
//here the user can register a new account or login

public class MainActivity extends AppCompatActivity {

    //login vars
    Button registerButton, loginButton;
    EditText username, password;
    String phoneNum,uname, pass, userGoal, sms;
    String tempPass = "NULL";
    SQLiteDatabase db;
    userDBhandler handler;
    Boolean isEmpty;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);
        username = findViewById(R.id.editTextUserName);
        password = findViewById(R.id.editTextPassword);

        handler = new userDBhandler(this);

        loginButton.setOnClickListener(view -> {
            loginClick();
        });
        registerButton.setOnClickListener(view -> {
            registerClick();
        });


    }


    //goes to the register activity
    public void registerClick(){
        Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
        startActivity(intent);
    }

    //here the edit text information is crossed against the User DB
    // if the user name and password match a username and password in the DB
    // will successfully log in to the rest of the app
    @SuppressLint("Range")
    public void loginClick(){
        String msg = CheckNotEmpty();

        if(!isEmpty){
            db = handler.getWritableDatabase();
            Cursor cursor = db.query(userDBhandler.TABLE_NAME, null," " + userDBhandler.NAME_COL +"=?",new String[]{uname},null,null,null );

            while (cursor.moveToNext()){
                if (cursor.isFirst()){
                    cursor.moveToFirst();
                    tempPass = cursor.getString(cursor.getColumnIndex(userDBhandler.PASSWORD_COL));
                    phoneNum = cursor.getString(cursor.getColumnIndex(userDBhandler.PHONENUM_COL));
                    userGoal = cursor.getString(cursor.getColumnIndex(userDBhandler.GOAL_COL));
                    sms = cursor.getString(cursor.getColumnIndex(userDBhandler.SMS_COL));
                    cursor.close();
                }
            }
            handler.close();

            VerifyLogin();
        }
        else {
            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
        }
    }

    //if the password in the editTextPassword is equal to password stored at the same user location in
    //the DB start the weightTrackingActivity
    public void VerifyLogin(){
        if (tempPass.equals(pass)) {
            Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_LONG).show();

            Intent intent = new Intent(MainActivity.this, WeightTrackingActivity.class);
            intent.putExtra("goal",userGoal);
            intent.putExtra("phone",phoneNum);
            intent.putExtra("sms",sms);
            startActivity(intent);

            username.getText().clear();
            password.getText().clear();
        }else {
            Toast.makeText(MainActivity.this, "Incorrect Password \nor User Not Found", Toast.LENGTH_LONG).show();
        }
        tempPass = "NULL";
    }

    //checks that the editText fields are not empty
    public String CheckNotEmpty(){
        String msg = "";
        uname = username.getText().toString().trim();
        pass = password.getText().toString().trim();

        if (uname.isEmpty()){
            username.requestFocus();
            isEmpty = true;
            msg = "Username is empty!";
        }else if(pass.isEmpty()){
            password.requestFocus();
            isEmpty= true;
            msg = "Password is empty!";
        }else {
            isEmpty = false;
        }
        return msg;
    }

}

