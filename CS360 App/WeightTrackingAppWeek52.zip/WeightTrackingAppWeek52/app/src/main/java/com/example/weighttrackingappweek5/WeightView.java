package com.example.weighttrackingappweek5;

import android.app.Activity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

//This class sets up what will be filling List View item on the weightTrackingActivity
//it reads the database in an array list and displays it

public class WeightView extends BaseAdapter {
    //vars
    private final Activity activity;
    private PopupWindow editWindow;
    ArrayList<Weight> Weights;
    weightHandler db;
    String goal;
    Boolean textSent = false;

    //constructor
    public WeightView(Activity activity, ArrayList<Weight> Weights, weightHandler db, String goal) {
        this.activity = activity;
        this.Weights = Weights;
        this.db = db;
        this.goal = goal;
    }

    //https://www.javacodegeeks.com/2013/09/android-viewholder-pattern-example.html
    public static class ViewHolderItem{
        TextView textViewDate;
        TextView textViewWeight;
        Button editButton;
        Button deleteButton;
    }

    @Override
    public int getCount() {
        return Weights.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }


    //Here is the where list view is built
    @Override
    public View getView(int i, View view1, ViewGroup viewGroup) {

        View v = view1;
        LayoutInflater inflater = activity.getLayoutInflater();
        ViewHolderItem viewHolderItem;

        if (view1 == null){
            viewHolderItem = new ViewHolderItem();
            v = inflater.inflate(R.layout.weight_template,null,true);

            viewHolderItem.textViewDate = v.findViewById(R.id.textViewDate);
            viewHolderItem.textViewWeight = v.findViewById(R.id.textViewWeight);
            viewHolderItem.editButton = v.findViewById(R.id.edit);
            viewHolderItem.deleteButton = v.findViewById(R.id.delete);

            v.setTag(viewHolderItem);
        }else {
            viewHolderItem = (ViewHolderItem) view1.getTag();
        }


        viewHolderItem.textViewWeight.setText(Weights.get(i).getWeight());
        viewHolderItem.textViewDate.setText(Weights.get(i).getDate());


        //Pulls the weights from the DB checks the weight against the goal if the weight is < the goal send an SMS
        String weight = viewHolderItem.textViewWeight.getText().toString().trim();
        int wt = Integer.parseInt(weight);
        int gl = Integer.parseInt(goal);

        if (wt < gl && !textSent){
            textSent = true;  //prevents a loop
            WeightTrackingActivity.SendSMS(activity.getApplicationContext());
        }



        final int pos = i;
        viewHolderItem.editButton.setOnClickListener(view -> editClick(pos));
        viewHolderItem.deleteButton.setOnClickListener(view ->{
            db.deleteWeight(Weights.get(pos));
            Weights = (ArrayList<Weight>) db.getAllWeights();
            notifyDataSetChanged();
            Toast.makeText(activity, "Item Deleted", Toast.LENGTH_LONG).show();
        });

        return v;
    }

    //adds a popup window to edit the date or the weight or both and updates them
    public void editClick(final int pos){
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.edit_weight, activity.findViewById(R.id.edit_element));

        editWindow = new PopupWindow(layout, 800, 1000, true);
        editWindow.showAtLocation(layout, Gravity.CENTER, 0,0);

        final EditText editTextWeight = layout.findViewById(R.id.editTextWeight1);
        final EditText editTextDate = layout.findViewById(R.id.editTextDate1);

        editTextDate.setText(Weights.get(pos).getDate());
        editTextWeight.setText(Weights.get(pos).getWeight());

        Button save = layout.findViewById(R.id.save);
        Button cancel = layout.findViewById(R.id.cancel);

        //updates the weights to the new values
        save.setOnClickListener(view -> {
            String weight = editTextWeight.getText().toString();
            String date = editTextDate.getText().toString();

            Weight weight1 = Weights.get(pos);
            weight1.setWeight(weight);
            weight1.setDate(date);

            db.updateWeight(weight1);
            Weights = (ArrayList<Weight>) db.getAllWeights();
            notifyDataSetChanged();
            Toast.makeText(activity,"Weight Updated",Toast.LENGTH_LONG).show();

            editWindow.dismiss();
        });
        //exits the edit popup
        cancel.setOnClickListener(view -> {
            Toast.makeText(activity, "Edit Canceled",Toast.LENGTH_LONG).show();
            editWindow.dismiss();
        });

    }

}
