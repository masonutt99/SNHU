package com.example.weighttrackingappweek5;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;


public class WeightTrackingActivity extends AppCompatActivity {
    Button addButton, logoutButton, deleteAllButton, smsButton;
    ArrayList<Weight> weightArrayList;
    int countWeights;
    ListView listView;
    weightHandler handler;
    WeightView weightView;
    String goal;
    static String phone;
    static String sms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database);

        addButton = findViewById(R.id.addWeight);
        logoutButton = findViewById(R.id.logout);
        deleteAllButton = findViewById(R.id.deleteAll);
        listView = findViewById(R.id.listView);
        smsButton = findViewById(R.id.smsMessages);

        goal = getIntent().getExtras().getString("goal");
        phone = getIntent().getExtras().getString("phone");
        sms = getIntent().getExtras().getString("sms");
        handler = new weightHandler(this);

        weightArrayList = (ArrayList<Weight>) handler.getAllWeights();
        countWeights = handler.getCountWeights();

        //if the database has any members open a new weightView that fills the listView item
        if (countWeights > 0){
            weightView = new WeightView(this, weightArrayList, handler, goal);
            listView.setAdapter(weightView);
        }else {
            Toast.makeText(WeightTrackingActivity.this, "Database is Empty",Toast.LENGTH_LONG).show();
        }

        //if clicked go to the addWeight page to add weight and date to a DB
        addButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, AddWeightActivity.class);
            intent.putExtra("goal",goal);
            intent.putExtra("phone",phone);
            intent.putExtra("sms",sms);
            startActivity(intent);
        });

        //deletes all items on the DB
        deleteAllButton.setOnClickListener(view -> {
            countWeights = handler.getCountWeights();
            if (countWeights > 0){
                handler.deleteAllWeights();
                Toast.makeText(this,"All weights deleted",Toast.LENGTH_LONG).show();
                if (weightView == null){
                    weightView = new WeightView(this, weightArrayList,handler, goal);
                    listView.setAdapter(weightView);
                }
                weightView.Weights = (ArrayList<Weight>) handler.getAllWeights();
                ((BaseAdapter) listView.getAdapter()).notifyDataSetChanged();
            }

        });

        //sends to the SMS page
        smsButton.setOnClickListener(view ->{

            Intent intent = new Intent(WeightTrackingActivity.this, SMSActivity.class);
            intent.putExtra("goal",goal);
            intent.putExtra("phone",phone);
            intent.putExtra("sms",sms);

            startActivity(intent);
            this.finish();
        });

    }


    //logs out of the database
    public void logOutClick(View view){
        Toast.makeText(WeightTrackingActivity.this, "Logout Successful",Toast.LENGTH_LONG).show();
        Intent intent = new Intent(WeightTrackingActivity.this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }

    //if sms privileges are true sends a SMS message congratulating on being below their goal weight
    public static void SendSMS(Context context){
        String p = phone;
        String s = sms;
        if (s.equals("true")){
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(p, null, "Congrats you are at or below your goal weight!", null, null);
                Toast.makeText(context, "SMS Sent", Toast.LENGTH_LONG).show();
            }catch (Exception exception){
                Toast.makeText(context, "Device Permission Denied", Toast.LENGTH_LONG).show();
            }
        }else {
            Toast.makeText(context, "Enable SMS for notifications", Toast.LENGTH_LONG).show();
        }
    }

}
