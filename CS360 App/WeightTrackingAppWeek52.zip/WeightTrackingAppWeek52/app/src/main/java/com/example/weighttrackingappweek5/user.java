package com.example.weighttrackingappweek5;

public class user {

    //This class holds the information for a users information
    //this will be the base of the database

    int userId;
    String userName;
    String phoneNumber;
    String password;
    String goal;
    String sms;   /// add this in registration and pass it through so can change later.

    public user(String uname, String phone, String pass, String goal, String sms){
        super();
        this.userName = uname;
        this.phoneNumber = phone;
        this.password = pass;
        this.goal = goal;
        this.sms = sms;
    }

    //constructor
    public user(int i, String userName, String phoneNumber, String password, String goal, String sms){
        super();
        this.userId = i;
        this.userName = userName;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.goal = goal;
        this.sms = sms;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String name) {
        this.userName = name;
    }

    public String getUserPhone() {
        return phoneNumber;
    }

    public void setUserPhone(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUserPass() {
        return password;
    }

    public void setUserPass(String password) {
        this.password = password;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public String getGoal() {
        return goal;
    }

    public String getSms() {
        return sms;
    }

    public void setSms(String sms) {
        this.sms = sms;
    }
}
