package com.example.weighttrackingappweek5;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class SMSActivity extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback {

    private static final int PERMISSION_REQUEST_SMS = 0;

    Button denyButton, acceptButton;
    String goal, phone, sms;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.textconsent);

        //checks the app permissions for SMS messages
        showTextPreview();

        goal = getIntent().getExtras().getString("goal");
        phone = getIntent().getExtras().getString("phone");
        sms = getIntent().getExtras().getString("sms");

        denyButton = findViewById(R.id.denyButton);
        acceptButton = findViewById(R.id.acceptButton);

        //changes a permission for denying text messages
        denyButton.setOnClickListener(view ->{
            Intent intent = new Intent(this, WeightTrackingActivity.class);
            sms = "false";
            intent.putExtra("sms", sms);
            intent.putExtra("phone", phone);
            intent.putExtra("goal",goal);
            Toast.makeText(SMSActivity.this, "SMS Permission Denied",Toast.LENGTH_LONG).show();
            startActivity(intent);
            this.finish();
        });

        //changes a permission for allowing text messages
        acceptButton.setOnClickListener(view ->{
            Intent intent = new Intent(this, WeightTrackingActivity.class);
            sms = "true";
            intent.putExtra("sms", sms);
            intent.putExtra("phone", phone);
            intent.putExtra("goal",goal);
            Toast.makeText(SMSActivity.this, "SMS Permission Granted",Toast.LENGTH_LONG).show();
            startActivity(intent);
            this.finish();
        });

    }

    //https://google-developer-training.github.io/android-developer-phone-sms-course/Lesson%202/2_p_sending_sms_messages.html
    //gets device permission to send texts, once granted it will stay granted
    public void showTextPreview(){
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SMS);
        }
    }
}
