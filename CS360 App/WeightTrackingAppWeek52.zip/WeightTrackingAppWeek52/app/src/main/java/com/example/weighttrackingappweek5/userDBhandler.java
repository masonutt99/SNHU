package com.example.weighttrackingappweek5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Objects;


//This is a handler class that creates the CRUD functionality of a database
//Create Delete Update Read


/*
https://www.geeksforgeeks.org/how-to-create-and-add-data-to-sqlite-database-in-android/
 */

public class userDBhandler extends SQLiteOpenHelper {

    // creating a constant variables for our database.
    private static final String DB_NAME = "UserData.DB";
    private static final int DB_VERSION = 1;
    public static final String TABLE_NAME = "UserTable";
    public static final String ID_COL = "id";
    public static final String NAME_COL = "name";
    public static final String PHONENUM_COL = "phoneNumber";
    public static final String PASSWORD_COL = "password";
    public static final String GOAL_COL = "goal";
    public static final String SMS_COL = "sms";

    // creating a constructor for our database handler.
    public userDBhandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // below method is for creating a database by running a sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        // on below line we are creating
        // an sqlite query and we are
        // setting our column names
        // along with their data types.
        String query = "CREATE TABLE IF NOT EXISTS "
                + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " VARCHAR, "
                + PHONENUM_COL + " VARCHAR, "
                + PASSWORD_COL + " VARCHAR, "
                + GOAL_COL + " VARCHAR, "
                + SMS_COL + " VARCHAR" + ");";

        // at last we are calling a exec sql
        // method to execute above sql query
        db.execSQL(query);
    }

    //Create a new member and insert it into DB
    public void addUser(user user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(NAME_COL, user.getUserName());
        values.put(PHONENUM_COL, user.getUserPhone());
        values.put(PASSWORD_COL, user.getUserPass());
        values.put(GOAL_COL, user.getGoal());
        values.put(SMS_COL, user.getSms());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    //Reads the user class from the spot in the DB
    public user readUser(int id){
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME,
                new String[] {ID_COL, NAME_COL, PHONENUM_COL, PASSWORD_COL, GOAL_COL, SMS_COL}, ID_COL + " = ?",
                new String[] {String.valueOf(id)}, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }

        user user = new user(Integer.parseInt(Objects.requireNonNull(cursor).getString(0)),
                cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5));
        cursor.close();

        return user;
    }

    //Update to fix user information
    public int updateUser(user user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(NAME_COL, user.getUserName());
        values.put(PHONENUM_COL, user.getUserPhone());
        values.put(PASSWORD_COL, user.getUserPass());
        values.put(GOAL_COL, user.getGoal());
        values.put(SMS_COL, user.getSms());

        return db.update(TABLE_NAME, values, ID_COL + " = ?", new String[] { String.valueOf(user.getUserId()) });
    }
    //Delete a user from Database
    public void deleteUser(user user){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, ID_COL + " = ?", new String[] { String.valueOf(user.getUserId()) });
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
