package com.example.weighttrackingappweek5;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;



//This class is the base of the register functionality and page
//get to this page from login page
//lets the user add information to userDB

public class RegisterActivity extends AppCompatActivity {

    //reg vars
    SQLiteDatabase db;
    userDBhandler handler;
    Button signUpButton;
    EditText usernameReg;
    EditText phoneReg;
    EditText passReg;
    EditText goalReg;
    String unameR, phoneR, passR, goalR;
    Boolean isEmptyReg;
    Boolean userAlreadyExists = false;



    String F_Result = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        signUpButton = findViewById(R.id.registerButton2);
        usernameReg = findViewById(R.id.editTextUserNameReg);
        phoneReg = findViewById(R.id.editTextPhoneNumberReg);
        passReg = findViewById(R.id.editTextPasswordReg);
        goalReg = findViewById(R.id.editTextGoalWeight);
        //checkBox = findViewById(R.id.checkBox);
        handler = new userDBhandler(this);


        signUpButton.setOnClickListener(view -> {
            signUpClick();
        });


    }


    //returns to login page without registering a new user // called in the xml
    public void exitClick(View view){
        Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }

    //checks if any of the fields are empty, if they are full it adds the user to the database of user information
    public void signUpClick(){
        String msg = CheckNotEmptyReg();

        if (!isEmptyReg){
            CheckUserExists();
            usernameReg.getText().clear();
            phoneReg.getText().clear();
            passReg.getText().clear();
            goalReg.getText().clear();

        }else {
            Toast.makeText(RegisterActivity.this, msg, Toast.LENGTH_LONG).show();
        }
    }

    //checks the text fields to see if all filled
    public String CheckNotEmptyReg(){
        String msg = "";

        unameR = usernameReg.getText().toString().trim();
        phoneR = phoneReg.getText().toString().trim();
        passR = passReg.getText().toString().trim();
        goalR = goalReg.getText().toString().trim();

        if (unameR.isEmpty()){
            usernameReg.requestFocus();
            isEmptyReg = true;
            msg = "Username is empty!";
        }else if(phoneR.isEmpty()){
            phoneReg.requestFocus();
            isEmptyReg= true;
            msg = "Phone number is empty!";
        } else if(passR.isEmpty()) {
            passReg.requestFocus();
            isEmptyReg = true;
            msg = "Password is empty!";
        }else if(goalR.isEmpty()){
            goalReg.requestFocus();
            isEmptyReg= true;
            msg = "Goal Weight is empty!";
        }else {
            isEmptyReg= false;
        }
        return msg;
    }

    //checks the DB to see if a user already exists
    public void CheckUserExists(){
        String uname = usernameReg.getText().toString().trim();
        db = handler.getWritableDatabase();

        Cursor cursor = db.query(userDBhandler.TABLE_NAME, null, " " + userDBhandler.NAME_COL +"=?", new String[]{uname} , null, null, null);

        while (cursor.moveToNext()){
            if (cursor.isFirst()){
                cursor.moveToFirst();
                userAlreadyExists = true;
                cursor.close();
            }
        }

        handler.close();

        if (userAlreadyExists){
            Toast.makeText(RegisterActivity.this, "Username Already Exists", Toast.LENGTH_LONG).show();
        }else{
            insertDB();
        }
        userAlreadyExists = false;
    }

    //adds the registered user into the DB
    public void insertDB(){
        String uname = usernameReg.getText().toString().trim();
        String phone = phoneReg.getText().toString().trim();
        String pass = passReg.getText().toString().trim();
        String goal = goalReg.getText().toString().trim();
        String sms;
        sms = "false";


        user user = new user(uname, phone, pass, goal, sms);
        handler.addUser(user);

        Toast.makeText(RegisterActivity.this, "Registered Successfully",Toast.LENGTH_LONG).show();

        Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }
}
