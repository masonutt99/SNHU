package com.example.weighttrackingappweek5;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

//this class is where the adding of new weights is handled

public class AddWeightActivity extends AppCompatActivity {

    Calendar calendar = Calendar.getInstance();
    EditText editDate, editWeight;
    weightHandler db;


    Button cancelButton, addWeightButton;
    String weight, date2, goal, phone, sms;
    Boolean isEmpty = true;
    DatePickerDialog.OnDateSetListener date;

    //https://stackoverflow.com/questions/14933330/datepicker-how-to-popup-datepicker-when-click-on-edittext
    //^^^ helped with the date pic

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_weight);

        goal = getIntent().getExtras().getString("goal");
        phone = getIntent().getExtras().getString("phone");
        sms = getIntent().getExtras().getString("sms");

        editWeight = findViewById(R.id.addNewWeight);
        editDate = findViewById(R.id.editDate);
        date = (datePicker, year, month, day) -> {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, day);
            updateEditDate();
        };
        editDate.setOnClickListener(view -> new DatePickerDialog(AddWeightActivity.this,
                date,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show());

        db = new weightHandler(this);

        addWeightButton = findViewById(R.id.enter);
        cancelButton = findViewById(R.id.canx);

        //inserts new weight into DB
        addWeightButton.setOnClickListener(view -> {
            insertDB();
        });

        //cancels the addition of the new weight
        cancelButton.setOnClickListener(view -> {
            Intent intent = new Intent(AddWeightActivity.this, WeightTrackingActivity.class);
            intent.putExtra("goal", goal);
            intent.putExtra("phone", phone);
            intent.putExtra("sms",sms);
            startActivity(intent);
            this.finish();
        });

    }

    //writes the date into the correct format
    public void updateEditDate(){
        String myDate = "MM/dd/yy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(myDate, Locale.US);
        editDate.setText(dateFormat.format(calendar.getTime()));
    }

    //checks if the fields are filled out then
    public String checkEmpty(){
        String msg = "Error";
        date2 = editDate.getText().toString().trim();
        weight = editWeight.getText().toString().trim();


        if (date2.isEmpty()){
            msg = "Date is Empty!";
            isEmpty = true;
        }else if (weight.isEmpty()){
            msg = "Weight is Empty";
            isEmpty = true;
        }else {
            isEmpty=false;
        }
        return msg;
    }

    //inserts new weight into the DB
    public void insertDB(){
        String msg = checkEmpty();

        if (!isEmpty) {
            String wt = editWeight.getText().toString().trim();
            String dt = editDate.getText().toString().trim();

            Weight weight = new Weight(dt, wt);
            db.addWeight(weight);

            Toast.makeText(AddWeightActivity.this, "Weight Added Successfully", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(AddWeightActivity.this, WeightTrackingActivity.class);
            intent.putExtra("goal", goal);
            intent.putExtra("phone", phone);
            intent.putExtra("sms",sms);
            startActivity(intent);
            this.finish();
        }else {
            Toast.makeText(AddWeightActivity.this, msg, Toast.LENGTH_LONG).show();
        }

    }

}

