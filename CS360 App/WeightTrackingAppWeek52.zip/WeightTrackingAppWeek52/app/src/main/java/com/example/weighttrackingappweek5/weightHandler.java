package com.example.weighttrackingappweek5;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

//This is a handler class that creates the CRUD functionality of a database
//Create Delete Update Read

public class weightHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "WeightData.DB";
    private static final int DB_VERSION = 1;
    public static final String TABLE_NAME = "WeightTable";
    public static final String ID_COL = "id";
    public static final String DATE_COL = "date";
    public static final String WEIGHT_COL = "weight";

    // creating a constructor for our database handler.
    public weightHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // below method is for creating a database by running a sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {

        // on below line we are creating
        // an sqlite query and we are
        // setting our column names
        // along with their data types.
        String query = "CREATE TABLE IF NOT EXISTS "
                + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + DATE_COL + " VARCHAR, "
                + WEIGHT_COL + " VARCHAR" + ");";
        // at last we are calling a exec sql
        // method to execute above sql query
        db.execSQL(query);
    }

    //Create a new member and insert it into DB
    public void addWeight(Weight weight){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(DATE_COL,weight.getDate());
        values.put(WEIGHT_COL,weight.getWeight());

        database.insert(TABLE_NAME,null,values);
        database.close();
    }
    //read individual weight
    public Weight readWeight(int id){
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME,
                new String[] {ID_COL, DATE_COL, WEIGHT_COL}, ID_COL + " = ?",
                new String[] {String.valueOf(id)}, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }

        Weight weight = new Weight(Integer.parseInt(Objects.requireNonNull(cursor).getString(0)),
                cursor.getString(1), cursor.getString(2));
        cursor.close();

        return weight;
    }

    //Update to fix weight information
    public int updateWeight(Weight weight){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(DATE_COL, weight.getDate());
        values.put(WEIGHT_COL, weight.getWeight());


        return db.update(TABLE_NAME, values, ID_COL + " = ?", new String[] { String.valueOf(weight.getId()) });
    }
    //delete a single weight from DB
    public void deleteWeight(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, ID_COL + " = ?", new String[] { String.valueOf(weight.getId()) });
        db.close();
    }
    //delete the whole DB
    public void deleteAllWeights() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME,null,null);
        db.close();
    }



    //returns an array list of all the weight classed
    public List<Weight> getAllWeights() {
        List<Weight> weightList = new ArrayList<>();

        SQLiteDatabase db = this.getWritableDatabase();
        try{
            String q = "SELECT * FROM " + TABLE_NAME;
            Cursor cursor = db.rawQuery(q, null);
            while (cursor.moveToNext()){
                Weight weight = new Weight();
                weight.setId(Integer.parseInt(cursor.getString(0)));
                weight.setDate(cursor.getString(1));
                weight.setWeight(cursor.getString(2));
                weightList.add(weight);
            }
            cursor.close();
        }catch (Exception e){
            Log.e(TAG, "Error " + e.toString());
        }

        return weightList;

    }
    //gets count of the number of weights in the database
    public int getCountWeights(){
        String q = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        int countWeights;

        Cursor cursor = db.rawQuery(q, null);
        countWeights = cursor.getCount();
        cursor.close();


        return countWeights;

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
