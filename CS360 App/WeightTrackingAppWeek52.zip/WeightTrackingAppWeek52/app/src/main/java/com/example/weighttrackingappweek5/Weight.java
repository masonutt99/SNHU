package com.example.weighttrackingappweek5;

public class Weight {
    int id;
    String date;
    String weight;

    //This class holds the information for a weight information
    //this will be the base of the database


    //constructors
    public Weight(){
        super();
    }
    public Weight(int i, String date, String weight){
        super();
        this.id = i;
        this.date = date;
        this.weight = weight;
    }

    public Weight(String date, String weight){
        super();
        this.date = date;
        this.weight = weight;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getWeight() {
        return weight;
    }
    public void setWeight(String weight) {
        this.weight = weight;
    }

}
